from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from .models import Message
from django.db.models import Q
from django.core.mail import send_mail
from item.models import Item

@login_required(login_url='/login/')
def NewMessage(request, item_id):
    item = Item.objects.get(id=item_id)
    receiver = item.created_by
    sender = request.user

    if request.method == 'POST':
        content = request.POST.get('content')
        message = Message.objects.create(item=item, receiver=receiver, sender=sender, content=content)
        message.save()

        subject = '您收到一則私人訊息(NCHU Market)'
        message = f'您收到来自 {sender.username} 的私人訊息, 請登入查看'
        from_email = 'buukhangtu@gmail.com'
        to_email = receiver.email
        send_mail(subject, message, from_email, [to_email])

        return redirect('/message_list/')

    return render(request, 'Message/create_message.html', locals())


@login_required(login_url='/login/')
def message_list(request):
    user = request.user
    received_messages = Message.objects.filter(receiver=user)
    sent_messages = Message.objects.filter(sender=user)
    return render(request, 'Message/message_list.html', {'received_messages': received_messages, 'sent_messages': sent_messages})


@login_required(login_url='/login/')
def user_message(request, user_id):
    current_user = request.user
    other_user = get_object_or_404(get_user_model(), id=user_id)
    messages = Message.objects.filter((Q(sender=current_user) & Q(receiver=other_user)) | (Q(sender=other_user) & Q(receiver=current_user))).order_by('-pub_time')

    if request.method == 'POST':
        item_id = request.POST.get('item_id')
        content = request.POST.get('content')
        item = get_object_or_404(Item, id=item_id)
        message = Message.objects.create(item=item, receiver=other_user, sender=current_user, content=content)
        message.save()

        subject = '您收到一則私人訊息(NCHU Market)'
        message = f'您收到来自 {current_user.username} 的私人訊息, 請登入查看'
        from_email = 'buukhangtu@gmail.com'
        to_email = other_user.email
        send_mail(subject, message, from_email, [to_email])

        return redirect('/message_list/')

    return render(request, 'Message/user_message.html', locals())
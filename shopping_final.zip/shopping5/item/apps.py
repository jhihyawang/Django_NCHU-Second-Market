from django.apps import AppConfig


class ItemConfig(AppConfig):
    name = 'item'

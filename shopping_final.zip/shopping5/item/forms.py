from django import forms
from .models import Item
from captcha.fields import CaptchaField

INPUT_CLASSES = 'w-full py-4 px-6 rounded-xl border'
class NewItemForm(forms.ModelForm):
    captcha = CaptchaField()
    class Meta:
         model = Item
         fields = ('category','name','description','price','status','image')
         widgets = {
              'category':forms.Select(attrs={
                   'class':INPUT_CLASSES
              }),
              'name':forms.TextInput(attrs={
                   'class':INPUT_CLASSES
              }),
              'description':forms.Textarea(attrs={
                   'class':INPUT_CLASSES
              }),
              'price':forms.TextInput(attrs={
                   'class':INPUT_CLASSES
              }),
              'status':forms.Select(attrs={
                   'class':INPUT_CLASSES
              }),
              'image':forms.FileInput(attrs={
                   'class':INPUT_CLASSES
              }),
         }
    def __init__(self,*args,**kwargs):
         super(NewItemForm,self).__init__(*args,**kwargs)
         self.fields['category'].label = '商品類型'
         self.fields['name'].label = '商品名稱'
         self.fields['description'].label = '商品描述'
         self.fields['price'].label = '商品售價'
         self.fields['status'].label = '商品狀況'
         self.fields['image'].label = '商品圖片'
         self.fields['captcha'].label = '不是機器人'

class EditItemForm(forms.ModelForm):
    captcha = CaptchaField()
    class Meta:
         model = Item
         fields = ('name','description','price','status','image','is_sold')
         widgets = {
              'name':forms.TextInput(attrs={
                   'class':INPUT_CLASSES
              }),
              'description':forms.Textarea(attrs={
                   'class':INPUT_CLASSES
              }),
              'price':forms.TextInput(attrs={
                   'class':INPUT_CLASSES
              }),
              'status':forms.Select(attrs={
                   'class':INPUT_CLASSES
              }),
              'image':forms.FileInput(attrs={
                   'class':INPUT_CLASSES
              }),
         }
    def __init__(self,*args,**kwargs):
         super(EditItemForm,self).__init__(*args,**kwargs)
         self.fields['name'].label = '商品名稱'
         self.fields['description'].label = '商品描述'
         self.fields['price'].label = '商品售價'
         self.fields['status'].label = '商品狀況'
         self.fields['image'].label = '商品圖片'
         self.fields['captcha'].label = '不是機器人'
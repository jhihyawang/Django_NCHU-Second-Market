from django.contrib import admin
from .models import Category,Item,Cart
# Register your models here.

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name','pub_time')

class ItemAdmin(admin.ModelAdmin):
    list_display = ('category','name','description','price','image','status','is_sold','created_by','created_at')
    ordering = ('-created_at',)

class CartAdmin(admin.ModelAdmin):
    list_display = ('user',)


admin.site.register(Category,CategoryAdmin)
admin.site.register(Item,ItemAdmin)
admin.site.register(Cart,CartAdmin)
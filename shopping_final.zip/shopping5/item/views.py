from django.shortcuts import render,redirect, get_object_or_404
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from .models import Category,Item,Cart
from .forms import NewItemForm,EditItemForm
# Create your views here.
def index(request):
    items = Item.objects.filter(is_sold=False)[0:6]
    categories = Category.objects.all() 
    return render(request,'item/index.html',{'items':items,'categories':categories})

def detail(request,id):
    item = Item.objects.get(id=id)
    related_items = Item.objects.filter(category=item.category,is_sold=False).exclude(id=id)[0:3]
    #最後改成只要有點入 點閱率就加一
    if ('hit_%s'% item.id) not in request.session:
        request.session['hit_%s' % item.id]= True
        item.hit += 1
        item.save()
    else:
        item.hit += 1
        item.save()
    return render(request,'item/detail.html',locals())

@login_required
def new(request):
    if request.method == 'POST':
        form = NewItemForm(request.POST,request.FILES)
        if form.is_valid():
            item = form.save(commit=False)
            item.created_by = request.user
            item.save()
            return redirect('/myitem')
    else:
        form=NewItemForm()

    return render(request,'item/form.html',locals())

@login_required
def show(request):
    items = Item.objects.filter(created_by =request.user)
    return render(request,'item/myitem.html',locals())

@login_required
def delete(request,id):
    item = Item.objects.get(id=id,created_by=request.user)
    item.delete()
    return redirect('/myitem')

@login_required
def edit(request,id):
    item = Item.objects.get(id=id,created_by=request.user)
    if request.method == 'POST':
        form = EditItemForm(request.POST,request.FILES,instance=item)
        if form.is_valid():
            form.save()
            return redirect('/myitem')
    else:
        form=EditItemForm(instance=item)

    return render(request,'item/form.html',locals())

def search(request):
    query = request.GET.get('query', '')
    category_id = request.GET.get('category', 0)
    categories = Category.objects.all()
    items = Item.objects.filter(is_sold=False)

    if category_id:
        items = items.filter(category_id=category_id)

    if query:
        items = items.filter(Q(name__icontains=query) | Q(description__icontains=query))

    return render(request, 'item/search.html', {
        'items': items,
        'query': query,
        'categories': categories,
        'category_id': int(category_id)
    })

@login_required(login_url='/login/')
def add_to_cart(request, id):
    item = get_object_or_404(Item, id=id)
    cart_item, created = Cart.objects.get_or_create(user=request.user, item=item)
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    return redirect('/search')

@login_required
def view_cart(request):
    cart_items = Cart.objects.filter(user=request.user)
    
    total_price = 0
    for cart_item in cart_items:
        total_price += cart_item.item.price * cart_item.quantity
    return render(request, 'item/view_cart.html', locals())

@login_required
def remove_from_cart(request, id):
    cart_item = get_object_or_404(Cart, id=id, user=request.user)
    cart_item.delete()
    return redirect('cart')